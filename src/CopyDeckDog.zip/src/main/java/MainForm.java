import com.sun.jmx.snmp.tasks.Task;
import controller.LangManager;
import model.Data;
import model.DeckListRow;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import view.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Map;
import java.util.Random;

import static controller.LangManager.langMap;
import static model.Data.deckListRows;
import static model.Data.singleRankButtonMap;
import static model.Data.singleRankRowState;

public class MainForm {
    private JTable table;
    private JButton getListButton;
    private JPanel mainPanel;
    private JRadioButton uploadDateRadioButton;
    private JRadioButton updateDateRadioButton;
    private JRadioButton goodRadioButton;
    private JRadioButton watchRadioButton;
    private JTextArea noteTextArea;
    private JButton aboutButton;
    private JRadioButton formatButton1;
    private JRadioButton formatButton2;
    private JProgressBar progressBar;

    public static void main(String[] args) {

        /*try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }*/

        JFrame frame = new JFrame("CopyDeckDog Beta 1.0");
        frame.setContentPane(new MainForm().mainPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800,600);
        frame.setLocationRelativeTo(null);
        //frame.pack();
        frame.setVisible(true);

        //java.net.URL imgURL = MainForm.class.getResource("/images/Snap1.jpg");
        java.net.URL imgURL;
        imgURL = MainForm.class.getResource("images/11548522.jpg");
        if(imgURL==null)
            imgURL = MainForm.class.getResource("/images/11548522.jpg");
        ImageIcon img = new ImageIcon(imgURL );
        frame.setIconImage(img.getImage());


    }

    private Task task;

    public MainForm() {
        //initTable();
        noteTextArea.setText("只會顯示目前卡表比賽有前幾名的牌組類型\n" +
                "選項影響的是，下載牌組挑選該類型排序中第一副\n" +
                "舉例：\n" +
                "勾選上傳日期，就是下載上傳日期最新的一副\n" +
                "勾選更新日期，就是下載更新日期最新的一副\n" +
                "勾選讚數，就是下載讚數最高的一副\n" +
                "勾選觀看數，就是下載觀看數最高的一副\n" +
                "↑簡單來講就是勾選自己認為最強的標準\n" +
                "\n" +
                "名詞解釋：\n" +
                "上位牌組：\n" +
                "目前比賽有前幾名紀錄的牌組");
        initRadioButton();

        getListButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                getListButton.setEnabled(false);
                mainPanel.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
                progressBar.setMaximum(3);
                progressBar.setValue(0);
                ProgressWorker pw = new ProgressWorker();
                pw.addPropertyChangeListener(new PropertyChangeListener() {

                    @Override
                    public void propertyChange(PropertyChangeEvent evt) {
                        String name = evt.getPropertyName();
                        if (name.equals("progress")) {
                            int progress = (int) evt.getNewValue();
                            progressBar.setValue(progress);
                            mainPanel.repaint();
                        } else if (name.equals("state")) {
                            SwingWorker.StateValue state = (SwingWorker.StateValue) evt.getNewValue();
                            switch (state) {
                                case DONE:
                                    getListButton.setEnabled(true);
                                    mainPanel.setCursor(null);
                                    initTable();
                                    break;
                            }
                        }
                    }

                });
                pw.execute();

                //fetchData();
                //
            }
        });

        aboutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AboutDialog aboutDialog = new AboutDialog();
                aboutDialog.pack();
                aboutDialog.setLocationRelativeTo(null);
                aboutDialog.setVisible(true);
            }
        });

        LangManager.initLang();

        Data.progressBar = progressBar;
        progressBar.setStringPainted(true);
    }

    private void initRadioButton() {

        uploadDateRadioButton.addActionListener(e -> Data.searchOption = 1);
        updateDateRadioButton.addActionListener(e -> Data.searchOption = 2);
        goodRadioButton.addActionListener(e -> Data.searchOption = 3);
        watchRadioButton.addActionListener(e -> Data.searchOption = 5);

        //matchRadioButton.addActionListener(e -> Data.filterOption = 1);
        //nomatchRadioButton.addActionListener(e -> Data.filterOption = 2);

        formatButton1.addActionListener(e -> Data.formatOption = 1);
        formatButton2.addActionListener(e -> Data.formatOption = 2);

    }

    private void initTable() {
        singleRankButtonMap.clear();

        String[] header = { "名次", "牌組名", "上位數" ,
                "一鍵抄牌","攻略","個人賽1位"};

        Object[][] tableInputs = new Object[deckListRows.size()][];
        Data.singleRankRowState= new int[deckListRows.size()];
        for(int i = 0;i < deckListRows.size();i++)
        {
            DeckListRow deckListRow= deckListRows.get(i);
            deckListRow.printInfo();

            tableInputs[i] = new Object[header.length];

            tableInputs[i][0] = deckListRow.getRank();
            String name = deckListRow.getName();
            if( langMap.containsKey(deckListRow.getName())){
                name = langMap.get(deckListRow.getName());
            }
            tableInputs[i][1] = name;
            tableInputs[i][2] = deckListRow.getNum();

            tableInputs[i][3] = "下載";

            tableInputs[i][4] = "Google";

            tableInputs[i][5] = "列表";
        }

        TableModel model = new DefaultTableModel(tableInputs, header) {
            public Class<?> getColumnClass(int column) {
                return getValueAt(0, column).getClass();
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                //System.out.println("isCellEditable: " + rowIndex + " " + columnIndex);
                if(columnIndex == 5){
                    if( singleRankRowState[rowIndex] == -1){
                        return false;
                    }else
                        return true;
                }else {
                    return true;
                }

            }
        };

        table.setRowHeight(30);

        table.setModel(model);
        table.getColumnModel().getColumn(3).setCellEditor(
                new CopyDeckButtonEditor());

        table.getColumnModel().getColumn(3).setCellRenderer(
                new MyButtonRenderer());

        table.getColumnModel().getColumn(4).setCellEditor(
                new GoogleButtonEditor());

        table.getColumnModel().getColumn(4).setCellRenderer(
                new MyButtonRenderer());


        table.getColumnModel().getColumn(5).setCellEditor(
                new SingleRankButtonEditor());

        table.getColumnModel().getColumn(5).setCellRenderer(
                new MyButtonRenderer());

        table.setRowSelectionAllowed(false);
        table.getColumnModel().getColumn(0).setPreferredWidth(27);
        table.getColumnModel().getColumn(2).setPreferredWidth(27);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
    }

    /**
         * https://ocg.xpg.jp/rank/rank.fcgi?Mode=6

         https://ocg.xpg.jp/rank/rank.fcgi?DeckType=Lo

         https://ocg.xpg.jp/deck/deck.fcgi?ListNo=302582

         https://ocg.xpg.jp/deck/deck.fcgi?ListNo=302582&Text=5
         */
    private void fetchData() {
        System.out.println("fetchData");

        URL url = null;
        try {
            url = new URL("https://ocg.xpg.jp/rank/rank.fcgi?Mode=6");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        Document xmlDoc = null;
        try {
            xmlDoc = Jsoup.parse(url, 3000);
        } catch (IOException e) {
            e.printStackTrace();
        }

        //轉中文
        String temp = xmlDoc.html();
        //System.out.println(temp);
        for (Map.Entry<String, String> entry : langMap.entrySet())
        {
            //System.out.println("1");
            temp = temp.replace(entry.getKey(),entry.getValue());
        }
        //System.out.println(temp);
        Document doc = Jsoup.parse(temp);

        Elements table = doc.select("table");
        Elements tbody = table.select("tbody");
        Elements tr = tbody.select("tr");
        //System.out.println(tr.get(0).text());
        //System.out.println("Title is "+table.text());

        deckListRows = new ArrayList<>();

        for(int i = 1;i < tr.size();i++) //tr.size()
        {
            Elements td = tr.get(i).select("td");


            String rank = td.get(0).text();
            String deckUrl = td.get(1).select("a").first().attr("href");
            String name = td.get(1).select("a").first().text();
            String num =  td.get(2).text();

            DeckListRow deckListRow = new DeckListRow(rank,name,deckUrl,num);
            deckListRows.add(deckListRow);

        }

    }

    class ProgressWorker extends SwingWorker<Object, Object> {

        @Override
        protected Object doInBackground() throws Exception {

            System.out.println("fetchData");

            URL url = null;
            try {
                url = new URL("https://ocg.xpg.jp/rank/rank.fcgi?Mode=6");
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }

            Document xmlDoc = null;
            try {
                xmlDoc = Jsoup.parse(url, 3000);
            } catch (IOException e) {
                e.printStackTrace();
            }

            setProgress(1);
            //轉中文
            String temp = xmlDoc.html();
            //System.out.println(temp);
            for (Map.Entry<String, String> entry : langMap.entrySet())
            {
                //System.out.println("1");
                temp = temp.replace(entry.getKey(),entry.getValue());
            }
            setProgress(2);
            //System.out.println(temp);
            Document doc = Jsoup.parse(temp);

            Elements table = doc.select("table");
            Elements tbody = table.select("tbody");
            Elements tr = tbody.select("tr");
            //System.out.println(tr.get(0).text());
            //System.out.println("Title is "+table.text());

            deckListRows = new ArrayList<>();

            for(int i = 1;i < tr.size();i++) //tr.size()
            {
                Elements td = tr.get(i).select("td");


                String rank = td.get(0).text();
                String deckUrl = td.get(1).select("a").first().attr("href");
                String name = td.get(1).select("a").first().text();
                String num =  td.get(2).text();

                DeckListRow deckListRow = new DeckListRow(rank,name,deckUrl,num);
                deckListRows.add(deckListRow);

            }
            setProgress(3);

            return null;
        }
    }
}
