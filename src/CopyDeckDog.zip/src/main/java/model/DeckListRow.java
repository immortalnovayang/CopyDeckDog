package model;

public class DeckListRow {
    String rank;
    String name;
    String url;
    String num;

    public DeckListRow(String rank, String name, String url, String num) {
        this.rank = rank;
        this.name = name;
        this.url = url;
        this.num = num;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public void printInfo(){
        System.out.println(rank+","+name+","+url+","+num);
    }
}
