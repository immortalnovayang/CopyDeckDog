package model;

import javax.swing.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;

public class Data {
    public static JProgressBar progressBar;
    public static ArrayList<DeckListRow> deckListRows; //牌組類型
    public static String webHost = "https://ocg.xpg.jp";
    public static String web_rank = webHost+"/rank/rank.fcgi";
    public static int searchOption = 1; //1=上傳日期 2=最新更新日期 3=讚數 5=觀看數
    public static int filterOption = 1; //1=是大會 2不是
    public static int formatOption = 1; //1=ydk, text
    public static PriorityQueue<DeckData> deckDataQueue; //單一副牌組
    public static ArrayList<DeckData> deckArrayList; //暫存上一副
    public static Map<String, JButton> singleRankButtonMap = new HashMap<>();

    public static int[] singleRankRowState;
}
