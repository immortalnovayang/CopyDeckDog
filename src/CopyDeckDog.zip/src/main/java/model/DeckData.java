package model;

import java.util.Comparator;

public class DeckData implements Comparable<DeckData>  {
    String name;
    String url;
    int number;

    public DeckData(String name, String url) {
        this.name = name;
        this.url = url;
    }

    public DeckData(String name, String url, int number) {
        this.name = name;
        this.url = url;
        this.number = number;
    }

    @Override
    public int compareTo(DeckData o) {
        return o.number - number ;
    }

    public String getName() {
        return name;
    }

    public String getUrl() {
        return url;
    }

    public int getNumber() {
        return number;
    }

    public void printInfo(){
        System.out.println("name = "+name+",url = "+url+" number = "+number);
    }


}
