package model;

import java.util.Comparator;

public  class PriorityQueueComparator implements Comparator<DeckData> {
    public int compare(DeckData s1, DeckData s2) {
        if (s1.number < s2.number) {
            return -1;
        }
        if (s1.number > s2.number) {
            return 1;
        }
        return 0;
    }
}