import model.DeckData;
import model.PriorityQueueComparator;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.PriorityQueue;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import view.AboutDialog;
import view.SingleRankButtonEditor;
import view.SingleRankDialog;

import static model.Data.deckDataQueue;

public class TestJsoup {
    public static void main(String[] args) {

        deckDataQueue = new PriorityQueue<>();
        deckDataQueue.add(new DeckData("決闘都市2017 中国遊戯王スーパーリーグ 成都 1位","deck.fcgi?ListNo=291169",3));
        deckDataQueue.add(new DeckData("a2","b",1));
        deckDataQueue.add(new DeckData("a3","b",2));
        deckDataQueue.add(new DeckData("a4","b",4));
        for(DeckData deckData:deckDataQueue){
            deckData.printInfo();
        }

        deckDataQueue.peek().printInfo();

        SingleRankDialog singleRankDialogDialog = new SingleRankDialog();
        singleRankDialogDialog.setTitle("單人賽冠軍");
        //singleRankDialogDialog.pack();
        singleRankDialogDialog.setSize(700,500);
        singleRankDialogDialog.setLocationRelativeTo(null);
        singleRankDialogDialog.setVisible(true);

        System.exit(0);

       // testJsoup();
        //testChrome();
    }

    private static void testJsoup() {
        /*
        try {
            Document xmlDoc = Jsoup.connect("https://www.ygo-sem.cn/html/0/5/4/71564252.html")
                    .header("Accept-Encoding", "gzip, deflate")
                    .userAgent("Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0")
                    .maxBodySize(0)
                    .timeout(600000)
                    .get();
            System.out.println(     xmlDoc.toString());

        } catch (IOException e) {
            e.printStackTrace();
        }*/
    }

    private static void testChrome() {
        /*
        System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
        // Create a new instance of the html unit driver
        // Notice that the remainder of the code relies on the interface,
        // not the implementation.
        WebDriver driver = new ChromeDriver();

        // And now use this to visit Google
        driver.get("http://www.google.com");

        // Find the text input element by its name
        WebElement element = driver.findElement(By.name("q"));

        // Enter something to search for
        element.sendKeys("Cheese!");

        // Now submit the form. WebDriver will find the form for us from the element
        element.submit();

        // Check the title of the page
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Page title is: " + driver.getTitle());*/
    }


}
