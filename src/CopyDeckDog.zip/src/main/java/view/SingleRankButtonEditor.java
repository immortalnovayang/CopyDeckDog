package view;

import model.Data;
import model.DeckData;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import javax.swing.*;
import javax.swing.table.TableCellEditor;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;
import java.util.PriorityQueue;

import static model.Data.*;

public class SingleRankButtonEditor extends AbstractCellEditor implements
        TableCellEditor {

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -6546334664166791132L;

    private JPanel panel;

    private JButton button;
    private boolean matchDeck;
    private Object numberOfPeople;
    String deckName;
    String rankingUrl;
    boolean isProcessing = true;

    public SingleRankButtonEditor() {

        initButton();

        initPanel();

        panel.add(this.button, BorderLayout.CENTER);
    }

    private void initButton() {
        button = new JButton();

        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                fireEditingStopped();
            }
        });


    }

    private void initPanel() {
        panel = new JPanel();

        panel.setLayout(new BorderLayout());
    }

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value,
                                                 boolean isSelected, int row, int column) {

        disableAllButton();

        button.setText("列表");
        progressBar.setValue(0);
        progressBar.setMaximum(100);
        panel.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

        deckName = deckListRows.get(row).getName();;
        String deckUrl = deckListRows.get(row).getUrl();
        System.out.println("deckUrl = "+deckUrl);
        rankingUrl = getRankingUrl(web_rank + deckUrl);
        System.out.println("rankingUrl"+rankingUrl);

        ProgressWorker pw = new ProgressWorker();
        pw.addPropertyChangeListener(new PropertyChangeListener() {

            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                String name = evt.getPropertyName();
                if (name.equals("progress")) {
                    int progress = (int) evt.getNewValue();
                    progressBar.setValue(progress);
                    panel.repaint();
                } else if (name.equals("state")) {
                    SwingWorker.StateValue state = (SwingWorker.StateValue) evt.getNewValue();
                    switch (state) {
                        case DONE:
                            //button.setEnabled(true);
                            enableAllButton();
                            panel.setCursor(null);
                            for(DeckData deckData:deckDataQueue){
                                deckData.printInfo();
                            }
                            openDeckDialog();

                            break;
                    }
                }
            }

        });
        pw.execute();

        //System.out.println("latestDeckUrl"+latestDeckUrl);

        //System.out.println(ydkStr);

        //showSaveFileDialog(ydkStr, table);

        return panel;
    }

    private void disableAllButton() {
        for (int i = 0; i < singleRankRowState.length; i++) {
            singleRankRowState[i] = -1;
        }
    }

    private void enableAllButton() {
        for (int i = 0; i < singleRankRowState.length; i++) {
            singleRankRowState[i] = 0;
        }
    }

    private void saveFile(String ydkStr, String savePath) {

        //加上副檔名
        ydkStr = ydkStr.replace("\n","\r\n");
        System.out.println("之前" + savePath);

        if(Data.formatOption==1){
            if (!savePath.matches("([^\\s]+(\\.(?i)(ydk))$)")) {
                savePath = savePath + ".ydk";
                System.out.println(savePath);
            }
        }else if(Data.formatOption==2){

            if (!savePath.matches("([^\\s]+(\\.(?i)(txt))$)")) {
                savePath = savePath + ".txt";
                System.out.println(savePath);
            }
        }

        OutputStreamWriter out;

        try {
            out = new OutputStreamWriter(new FileOutputStream(savePath),"UTF-8");
            out.write(ydkStr);
            out.close();
        } catch (IOException ioe) {
            System.out.print(ioe);
        }

    }

    /**
     * https://ocg.xpg.jp/deck/deck_search.fcgi?DeckType=386
     * to
     * https://ocg.xpg.jp/deck/deck.fcgi?ListNo=302582
     */
    private void setDeckData(String rankingUrl) {

        URL url = null;
        try {
            url = new URL(rankingUrl);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        Document xmlDoc = null;
        try {
            xmlDoc = Jsoup.parse(url, 3000);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Elements table = xmlDoc.select("table");
        Elements tbody = table.get(2).select("tbody");
        //System.out.println("tbody = " + tbody);

        Elements tr = tbody.select("tr");
        //System.out.println("tr = " +tr.size());
        deckDataQueue = new PriorityQueue<>();
        //progressBar.setMaximum(tr.size());

        for (Element trRow : tr) {

            Elements td = trRow.select("td");
            Element a = td.select("a").first();
            if (a != null) {
                String name = a.text();
                //System.out.println(name);
                if (name.contains("1位") && isSingleDeck(name)) {
                    String deckUrl = td.select("a").first().attr("href");
                    System.out.println(name);
                    int num = -1;
                    try
                    {
                        Thread.sleep(500 + ((int) (Math.random() * 1000)));
                        progressBar.setValue(progressBar.getValue()+1);
                        num = getNumberOfPeople("https://ocg.xpg.jp/deck/"+deckUrl);
                    }
                    catch(InterruptedException ex)
                    {
                        Thread.currentThread().interrupt();
                    }
                    if(num>0){
                        DeckData deckData = new DeckData(name,deckUrl,num);
                        deckDataQueue.add(deckData);
                    }
                }
            }
        }

        progressBar.setValue(100);

        for(DeckData deckData:deckDataQueue){
            deckData.printInfo();
        }

        openDeckDialog();
    }

    private void openDeckDialog() {
        SingleRankDialog singleRankDialogDialog = new SingleRankDialog();

        singleRankDialogDialog.setTitle("單人賽冠軍 分類："+deckName);
        //singleRankDialogDialog.pack();
        singleRankDialogDialog.setSize(700,500);
        singleRankDialogDialog.setLocationRelativeTo(null);
        singleRankDialogDialog.setVisible(true);


    }


    private String getRankingUrl(String s) {

        URL url = null;
        try {
            url = new URL(s);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        Document xmlDoc = null;
        try {
            xmlDoc = Jsoup.parse(url, 3000);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Element div = xmlDoc.getElementById("s_result");
        String deckType = div.select("a").first().attr("href");

        String filter = "&Flt=1"; //賽場牌
        String sortStr = "";
        switch (searchOption) {
            case 1:
                sortStr = "&Sort=1";
                break;
            case 2:
                sortStr = "&Sort=2";
                break;
            case 3:
                sortStr = "&Sort=3";
                break;
            case 5:
                sortStr = "&Sort=5";
                break;
        }

        switch (filterOption) {
            case 1:
                filter = "&Flt=1"; //賽場牌
                break;
            case 2:
                filter = "&Flt=2"; //賽場牌
                break;
        }

        //System.out.println(webHost + deckType + filter + sortStr);

        return webHost + deckType + filter + sortStr;
    }

    @Override
    public Object getCellEditorValue() {
        return "列表";
    }

    public boolean isSingleDeck(String name) {
        if(name.contains("1位A"))
            return false;
        if(name.contains("1位B"))
            return false;
        if(name.contains("1位C")) //只用C會過濾到CS
            return false;
        return true;
    }

    public boolean isCSDeck(String name) {
        if(name.contains("CS"))
            return true;
        return false;
    }


    public int getNumberOfPeople(String deckUrl) {


        URL url = null;
        try {
            url = new URL(deckUrl);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        Document xmlDoc = null;
        try {
            xmlDoc = Jsoup.parse(url, 3000);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Element mainDiv = xmlDoc.getElementById("main");
        Elements pTag = mainDiv.select("p");
        Element numPTag = pTag.get(2);
        String s = numPTag.text();

        int num = -1;//人數
        if(s.length()>0&&s.contains("名")){
            try
            {
                s = s.substring(s.indexOf("参加者数")+5,s.indexOf("名"));

                try{
                    num = Integer.parseInt(s);
                }catch (Exception ex){

                }

            }catch (Exception ex){
                //ex.printStackTrace();
            }
        }

        return num;
    }




    class ProgressWorker extends SwingWorker<Object, Object> {

        @Override
        protected Object doInBackground() throws Exception {

            //setDeckData(rankingUrl);
            URL url = null;
            try {
                url = new URL(rankingUrl);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }

            Document xmlDoc = null;
            try {
                xmlDoc = Jsoup.parse(url, 3000);
            } catch (IOException e) {
                e.printStackTrace();
            }

            Elements table = xmlDoc.select("table");
            Elements tbody = table.get(2).select("tbody");
            //System.out.println("tbody = " + tbody);

            Elements tr = tbody.select("tr");
            //System.out.println("tr = " +tr.size());
            deckDataQueue = new PriorityQueue<>();
            //progressBar.setMaximum(tr.size());

            for (Element trRow : tr) {
                setProgress(getProgress()+1);
                Elements td = trRow.select("td");
                Element a = td.select("a").first();
                if (a != null) {
                    String name = a.text();
                    //System.out.println(name);
                    if (name.contains("1位") && isSingleDeck(name)) {
                        String deckUrl = td.select("a").first().attr("href");
                        System.out.println(name);
                        int num = -1;
                        try
                        {
                            Thread.sleep(500 + ((int) (Math.random() * 1000)));
                            progressBar.setValue(progressBar.getValue()+1);
                            num = getNumberOfPeople("https://ocg.xpg.jp/deck/"+deckUrl);
                        }
                        catch(InterruptedException ex)
                        {
                            Thread.currentThread().interrupt();
                        }
                        if(num>0){
                            DeckData deckData = new DeckData(name,deckUrl,num);
                            deckDataQueue.add(deckData);
                        }
                    }
                }
            }
            setProgress(100);




            return null;
        }
    }


}