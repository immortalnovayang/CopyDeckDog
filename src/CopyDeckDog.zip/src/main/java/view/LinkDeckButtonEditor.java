package view;

import model.DeckData;

import javax.swing.*;
import javax.swing.table.TableCellEditor;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.net.URL;

import static controller.Browser.openWebpage;
import static model.Data.deckArrayList;
import static model.Data.deckListRows;

public class LinkDeckButtonEditor extends AbstractCellEditor implements
        TableCellEditor {

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -6546334664166791132L;

    private JPanel panel;

    private JButton button;

    public LinkDeckButtonEditor() {

        initButton();

        initPanel();

        panel.add(this.button, BorderLayout.CENTER);
    }

    private void initButton() {
        button = new JButton();

        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                fireEditingStopped();
            }
        });

    }

    private void initPanel() {
        panel = new JPanel();

        panel.setLayout(new BorderLayout());
    }

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value,
                                                 boolean isSelected, int row, int column) {

        String deckLink = deckArrayList.get(row).getUrl();
        String deckStr = "https://ocg.xpg.jp/deck/";

        try {
            openWebpage(new URL(deckStr+deckLink));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        button.setText("連結");

        return panel;
    }

    @Override
    public Object getCellEditorValue() {
        return "連結";
    }

}