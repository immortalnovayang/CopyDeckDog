package view;

import javax.swing.*;
import java.awt.event.*;
import java.net.MalformedURLException;
import java.net.URL;

import static controller.Browser.openWebpage;

public class AboutDialog extends JDialog {
    private JPanel contentPane;
    private JButton buttonOK;
    private JButton buttonCancel;
    private JTextArea myTextArea1;
    private JButton deckbutton1;

    public AboutDialog() {
        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(buttonOK);

        buttonOK.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onOK();
            }
        });

        buttonCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        });

        // call onCancel() when cross is clicked
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

        // call onCancel() on ESCAPE
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        myTextArea1.setText("本工具資訊來源是抄牌網\n" +
                "主要是快速產生牌組用，" +
                "想要知道更多的牌組資訊，請參閱抄牌網\n" +
                "https://ocg.xpg.jp/deck/deck.fcgi");

        deckbutton1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    openWebpage(new URL("https://ocg.xpg.jp/deck/deck.fcgi"));
                } catch (MalformedURLException e1) {
                    e1.printStackTrace();
                }
            }
        });
    }

    private void onOK() {
        // add your code here
        try {
            openWebpage(new URL("http://immortalnova.hatenablog.com/"));
        } catch (MalformedURLException e1) {
            e1.printStackTrace();
        }
        //dispose();
    }

    private void onCancel() {
        // add your code here if necessary
        dispose();
    }

    public static void main(String[] args) {
        AboutDialog dialog = new AboutDialog();
        dialog.pack();
        dialog.setVisible(true);
        System.exit(0);
    }
}
