package view;

import controller.FileChooserTool;
import model.Data;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.prefs.Preferences;

import javax.swing.AbstractCellEditor;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.TableCellEditor;

import static model.Data.*;

public class CopyDeckButtonEditor extends AbstractCellEditor implements
        TableCellEditor {

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -6546334664166791132L;

    private JPanel panel;

    private JButton button;

    public CopyDeckButtonEditor() {

        initButton();

        initPanel();

        panel.add(this.button, BorderLayout.CENTER);
    }

    private void initButton() {
        button = new JButton();

        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                fireEditingStopped();
            }
        });

    }

    private void initPanel() {
        panel = new JPanel();

        panel.setLayout(new BorderLayout());
    }

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value,
                                                 boolean isSelected, int row, int column) {

        String deckUrl = deckListRows.get(row).getUrl();

        String rankingUrl = getRankingUrl(web_rank + deckUrl);

        String latestDeckUrl = getLatestDeckUrl(rankingUrl);


        String ydkStr = "";
        if(Data.formatOption==1){
            ydkStr = getYDKString(latestDeckUrl + "&Text=5");
        }else  if(Data.formatOption==2){
            ydkStr = getYDKString(latestDeckUrl + "&Text=1");
        }

        //System.out.println(ydkStr);

        showSaveFileDialog(ydkStr, table);

        return panel;
    }

    private void showSaveFileDialog(String ydkStr, JTable table) {

        //讀取上次的路徑
        //Preferences pref = Preferences.userNodeForPackage(CopyDeckButtonEditor.class);
        Preferences pref = Preferences.userRoot();
        String lastPath = pref.get("lastPath", "");
        System.out.println("pref = " + lastPath);

        JFileChooser fileChooser = null;
        if (!lastPath.equals("")) {
            fileChooser = new JFileChooser(lastPath);
        } else {
            fileChooser = new JFileChooser();
        }

        fileChooser.setDialogTitle("Specify a deck file to save");
        //fileChooser.setFileFilter(new YDKFileFilter("ydk", "*.ydk(ADS Deck File)"));
        //int userSelection =fileChooser.showOpenDialog(null);
        if(Data.formatOption==1){
            FileChooserTool.setFileType(fileChooser,"ydk");
        }else  if(Data.formatOption==2){
            FileChooserTool.setFileType(fileChooser,"txt");
        }

        int userSelection = fileChooser.showSaveDialog(null);




        String savePath = "";

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            //存這次路徑給下次用
            String temp = fileToSave.getPath();
            temp = temp.substring(0,temp.length()-fileToSave.getName().length());
            //System.out.println(temp);

            pref.put("lastPath", temp);

            System.out.println("Save as file: " + fileToSave.getAbsolutePath());
            savePath = fileToSave.getAbsolutePath();

            saveFile(ydkStr, savePath);

            button.setText("下載");
        }else {
            button.setText("下載");

        }

    }

    private void saveFile(String ydkStr, String savePath) {

        //加上副檔名
        ydkStr = ydkStr.replace("\n","\r\n");
        System.out.println("之前" + savePath);

        if(Data.formatOption==1){
            if (!savePath.matches("([^\\s]+(\\.(?i)(ydk))$)")) {
                savePath = savePath + ".ydk";
                System.out.println(savePath);
            }
        }else if(Data.formatOption==2){

            if (!savePath.matches("([^\\s]+(\\.(?i)(txt))$)")) {
                savePath = savePath + ".txt";
                System.out.println(savePath);
            }
        }

        OutputStreamWriter out;

        try {
            out = new OutputStreamWriter(new FileOutputStream(savePath),"UTF-8");
            out.write(ydkStr);
            out.close();
        } catch (IOException ioe) {
            System.out.print(ioe);
        }

    }

    private String getYDKString(String s) {

        URL url = null;
        try {
            url = new URL(s);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        Document xmlDoc = null;
        try {
            xmlDoc = Jsoup.parse(url, 3000);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Elements table = xmlDoc.select("pre");


        return table.text();
    }

    /**
     * https://ocg.xpg.jp/deck/deck_search.fcgi?DeckType=386
     * to
     * https://ocg.xpg.jp/deck/deck.fcgi?ListNo=302582
     */
    private String getLatestDeckUrl(String rankingUrl) {

        URL url = null;
        try {
            url = new URL(rankingUrl);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        Document xmlDoc = null;
        try {
            xmlDoc = Jsoup.parse(url, 3000);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Elements table = xmlDoc.select("table");
        Elements tbody = table.get(1).select("tbody");

        Elements tr = tbody.select("tr");
        //System.out.println("tr = " +tr);
        Elements td = tr.get(2).select("td");
        //System.out.println("td = " +td);
        String latestUrl = td.select("a").first().attr("href");

        System.out.println(latestUrl);
        return "https://ocg.xpg.jp/deck/" + latestUrl;
    }

    private String getRankingUrl(String s) {

        URL url = null;
        try {
            url = new URL(s);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        Document xmlDoc = null;
        try {
            xmlDoc = Jsoup.parse(url, 3000);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Element div = xmlDoc.getElementById("s_result");
        String deckType = div.select("a").first().attr("href");

        String filter = "&Flt=1"; //賽場牌
        String sortStr = "";
        switch (searchOption) {
            case 1:
                sortStr = "&Sort=1";
                break;
            case 2:
                sortStr = "&Sort=2";
                break;
            case 3:
                sortStr = "&Sort=3";
                break;
            case 5:
                sortStr = "&Sort=5";
                break;
        }

        switch (filterOption) {
            case 1:
                filter = "&Flt=1"; //賽場牌
                break;
            case 2:
                filter = "&Flt=2"; //賽場牌
                break;
        }

        System.out.println(webHost + deckType + filter + sortStr);

        return webHost + deckType + sortStr;
    }

    @Override
    public Object getCellEditorValue() {
        return "下載";
    }

}