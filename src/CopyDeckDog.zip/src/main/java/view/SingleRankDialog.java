package view;

import model.Data;
import model.DeckData;
import model.DeckListRow;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import static controller.LangManager.langMap;
import static model.Data.deckArrayList;
import static model.Data.deckDataQueue;
import static model.Data.deckListRows;

public class SingleRankDialog extends JDialog {
    private JPanel contentPane;
    private JButton buttonOK;
    private JTable table;
    private JRadioButton formatButton1;
    private JRadioButton formatButton2;
    private JScrollPane scrollPane;

    public SingleRankDialog() {
        initTable();
        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(buttonOK);

        buttonOK.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onOK();
            }

        });

        formatButton1.addActionListener(e -> Data.formatOption = 1);
        formatButton2.addActionListener(e -> Data.formatOption = 2);
    }

    private void onOK() {
        // add your code here
        //System.exit(0);
        dispose();
    }

    public static void main(String[] args) {
        SingleRankDialog dialog = new SingleRankDialog();
        dialog.pack();
        dialog.setVisible(true);
        System.exit(0);
    }

    private void initTable() {

        String[] header = { "牌組名", "人數" ,
                "連結","下載"};

        Object[][] tableInputs = new Object[deckDataQueue.size()][];

        deckArrayList = new ArrayList<DeckData>();
        for(DeckData deckData:deckDataQueue){
            deckArrayList.add(deckData);
        }

        for(int i = 0;i < deckArrayList.size();i++){

            DeckData deckData = deckArrayList.get(i);
            deckData.printInfo();

            tableInputs[i] = new Object[header.length];

            tableInputs[i][0] = deckData.getName();

            tableInputs[i][1] = deckData.getNumber();

            tableInputs[i][2] = "連結";

            tableInputs[i][3] = "下載";
        }

        TableModel model = new DefaultTableModel(tableInputs, header) {
            public Class<?> getColumnClass(int column) {
                return getValueAt(0, column).getClass();
            }
        };

        table.setRowHeight(30);

        table.setModel(model);


        table.getColumnModel().getColumn(2).setCellEditor(
                new LinkDeckButtonEditor());

        table.getColumnModel().getColumn(2).setCellRenderer(
                new MyButtonRenderer());

        table.getColumnModel().getColumn(3).setCellEditor(
                new CopySingleDeckButtonEditor());

        table.getColumnModel().getColumn(3).setCellRenderer(
                new MyButtonRenderer());

        table.setRowSelectionAllowed(false);
        table.getColumnModel().getColumn(0).setMinWidth(150);
        //table.getColumnModel().getColumn(0).setPreferredWidth(100);
        table.getColumnModel().getColumn(1).setMaxWidth(50);
        //table.getColumnModel().getColumn(1).setPreferredWidth(1);
        //table.getColumnModel().getColumn(2).setPreferredWidth(10);
        table.getColumnModel().getColumn(2).setMaxWidth(70);
        //table.getColumnModel().getColumn(3).setPreferredWidth(10);
        table.getColumnModel().getColumn(3).setMaxWidth(70);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
    }
}
