package view;

import controller.FileChooserTool;
import model.Data;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import javax.swing.*;
import javax.swing.table.TableCellEditor;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.prefs.Preferences;

import static model.Data.*;

public class CopySingleDeckButtonEditor extends AbstractCellEditor implements
        TableCellEditor {

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -6546334664166791132L;

    private JPanel panel;

    private JButton button;

    public CopySingleDeckButtonEditor() {

        initButton();

        initPanel();

        panel.add(this.button, BorderLayout.CENTER);
    }

    private void initButton() {
        button = new JButton();

        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                fireEditingStopped();
            }
        });

    }

    private void initPanel() {
        panel = new JPanel();

        panel.setLayout(new BorderLayout());
    }

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value,
                                                 boolean isSelected, int row, int column) {

        String deckLink = deckArrayList.get(row).getUrl();
        String deckStr = "https://ocg.xpg.jp/deck/";

        String ydkStr = "";
        if(Data.formatOption==1){
            ydkStr = getYDKString(deckStr+deckLink + "&Text=5");
        }else  if(Data.formatOption==2){
            ydkStr = getYDKString(deckStr+deckLink + "&Text=1");
        }

        showSaveFileDialog(ydkStr, table);

        return panel;
    }

    private void showSaveFileDialog(String ydkStr, JTable table) {

        //讀取上次的路徑
        //Preferences pref = Preferences.userNodeForPackage(CopyDeckButtonEditor.class);
        Preferences pref = Preferences.userRoot();
        String lastPath = pref.get("lastPath", "");
        System.out.println("pref = " + lastPath);

        JFileChooser fileChooser = null;
        if (!lastPath.equals("")) {
            fileChooser = new JFileChooser(lastPath);
        } else {
            fileChooser = new JFileChooser();
        }

        fileChooser.setDialogTitle("Specify a deck file to save");
        //fileChooser.setFileFilter(new YDKFileFilter("ydk", "*.ydk(ADS Deck File)"));
        //int userSelection =fileChooser.showOpenDialog(null);
        if(Data.formatOption==1){
            FileChooserTool.setFileType(fileChooser,"ydk");
        }else  if(Data.formatOption==2){
            FileChooserTool.setFileType(fileChooser,"txt");
        }

        int userSelection = fileChooser.showSaveDialog(null);




        String savePath = "";

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            //存這次路徑給下次用
            String temp = fileToSave.getPath();
            temp = temp.substring(0,temp.length()-fileToSave.getName().length());
            //System.out.println(temp);

            pref.put("lastPath", temp);

            System.out.println("Save as file: " + fileToSave.getAbsolutePath());
            savePath = fileToSave.getAbsolutePath();

            saveFile(ydkStr, savePath);

            button.setText("下載");
        }else {
            button.setText("下載");

        }

    }

    private void saveFile(String ydkStr, String savePath) {

        //加上副檔名
        ydkStr = ydkStr.replace("\n","\r\n");
        System.out.println("之前" + savePath);

        if(Data.formatOption==1){
            if (!savePath.matches("([^\\s]+(\\.(?i)(ydk))$)")) {
                savePath = savePath + ".ydk";
                System.out.println(savePath);
            }
        }else if(Data.formatOption==2){

            if (!savePath.matches("([^\\s]+(\\.(?i)(txt))$)")) {
                savePath = savePath + ".txt";
                System.out.println(savePath);
            }
        }

        OutputStreamWriter out;

        try {
            out = new OutputStreamWriter(new FileOutputStream(savePath),"UTF-8");
            out.write(ydkStr);
            out.close();
        } catch (IOException ioe) {
            System.out.print(ioe);
        }

    }

    private String getYDKString(String s) {

        URL url = null;
        try {
            url = new URL(s);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        Document xmlDoc = null;
        try {
            xmlDoc = Jsoup.parse(url, 3000);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Elements table = xmlDoc.select("pre");


        return table.text();
    }

    @Override
    public Object getCellEditorValue() {
        return "下載";
    }

}