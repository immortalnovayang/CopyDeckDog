package controller;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class LangManager {
    public static Map<String, String> langMap = new HashMap<>();

    public static void initLang(){



        try {
            File file = new File("./ConverseCardName.txt");

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(
                            new FileInputStream(file), "UTF8"));

            String str;

            while ((str = in.readLine()) != null) {
                String[] strArr  =str.split("\t");
                if(strArr.length>1){
                    langMap.put(strArr[1],strArr[0]);
                }

            }

            in.close();
        }
        catch (UnsupportedEncodingException e)
        {
            System.out.println(e.getMessage());
        }
        catch (IOException e)
        {
            System.out.println(e.getMessage());
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }


    }

}
