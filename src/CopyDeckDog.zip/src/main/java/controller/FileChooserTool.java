package controller;

import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import java.io.File;

public class FileChooserTool {
    public static void setFileType(JFileChooser fileChooser, String type){
        switch (type){
            case "ydk":
                fileChooser.setFileFilter(new FileFilter() {

                    public String getDescription() {
                        return "牌組檔案 (*.ydk)";
                    }

                    public boolean accept(File f) {
                        if (f.isDirectory()) {
                            return true;
                        } else {
                            String filename = f.getName().toLowerCase();
                            return filename.endsWith(".ydk") ;
                        }
                    }
                });
                break;
            case "txt":
                fileChooser.setFileFilter(new FileFilter() {

                    public String getDescription() {
                        return "文字卡表檔案 (*.txt)";
                    }

                    public boolean accept(File f) {
                        if (f.isDirectory()) {
                            return true;
                        } else {
                            String filename = f.getName().toLowerCase();
                            return filename.endsWith(".txt") ;
                        }
                    }
                });
                break;
        }
    }
}
