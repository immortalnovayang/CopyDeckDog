package util;

import java.net.URL;

public class StrTool {

}
